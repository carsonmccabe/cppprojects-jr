#include <iostream>
#include <string>
using namespace std; 

// This is my own work.
// Carson Walker

int main ()
{
	float h, d;
	const double pi = 3.14159;
	float volumeInches;
	float volumeMilliliters;

	cout<< "What is the height of the cylinder in inches?\n";
	cin>> h;
	cout<< "What is the diameter of the cylinder in inches?\n";
	cin>> d;
	volumeInches = .25 * h * pi * d * d;
	volumeMilliliters = volumeInches * 16.387;
	cout<<"The volume is "
	<<volumeMilliliters
	<<" milliliters (ml).";
	
	
	return 0;
}
