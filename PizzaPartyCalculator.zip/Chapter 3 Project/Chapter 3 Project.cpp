#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std; 

//Carson Walker
//This is my own work

int main()
{
	//establish constants and variables
	const double PI=3.14159,SLICE_AREA=14.125;
	double pizzaRadius, pizzaArea, slicesPerPizza;
	int slicesPerPerson = 2, numPeople, pizzaDiameter, 
		numPizzasNeeded;
	
	//prompt user for pizza size and number of people
	cout<<"What size pizza do you want (in inches)?\n";
	cin>> pizzaDiameter;
	cout<<"How many people will be attending?\n";
	cin>> numPeople;
	
	//calculate
	pizzaRadius = pizzaDiameter / 2;
	pizzaArea = pow(pizzaRadius,2) * PI;
	slicesPerPizza = pizzaArea / SLICE_AREA;
	numPizzasNeeded = ceil((numPeople * slicesPerPerson) / slicesPerPizza);
	
	//provide response
	cout<<"The number of pizzas you will need for "<<numPeople
	<< " people is "<< numPizzasNeeded<< " pizzas.";
	
	return 0;
}
