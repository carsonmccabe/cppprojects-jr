//Carson Walker
//This is my own work

#include <iostream>
using namespace std;

int main()
{
	//Prompt input
	cout << "Enter a fraction (i.e 8/12)\n";
	int n, d;
	char slash;
	cin >> n >> slash >> d;
	
	int n_orig, d_orig;
	n_orig = n;
	d_orig = d;
	
	//Repeat input
	cout << "You entered " << n << "/" << d << endl;
	
	//Find GCD
	while (n != d)
	{
		if (n > d)
		n = n - d;
		
		else if (d > n)
		d = d - n;
	}
	
	int gcd = d;
	
	//Reduce
	int n_reduced, d_reduced;
	n_reduced = n_orig / gcd;
	d_reduced = d_orig / gcd;
	
	//Display results
	cout << "The reduced fraction is " << n_reduced << "/" << d_reduced<<endl;
	
	cout << "The greatest common divisor is "<< gcd << endl;

	return 0;
}
